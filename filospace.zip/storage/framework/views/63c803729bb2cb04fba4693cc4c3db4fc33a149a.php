

<?php $__env->startSection('content'); ?>

<style>
    table {
        background-color: white;
        width: 90% !important;
        margin: auto;
        text-align: center; 
    }

    thead {
        background-color: #e1e1e1;
        border: solid 1px #e1e1e1 !important;
    }

    th {
        border: none !important;
    }

    tr {
        vertical-align: middle;
    }

    td {
        max-width:100px; 
        word-wrap:break-word;
    }

    .btn-outline, .btn-outline:hover {
        background-color: #717C73 !important;
        color: white;
    }

</style>

<div class="container-fluid">
    <div class="card" style="min-height: 90vh;">
        <div class="card-body p-5">
            <h4 class="text-center">List of Products</h4>
            <br><hr><br>
            <?php echo $__env->make('layouts.notifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <a href="<?php echo e(route('product.create')); ?>">
                <button class="btn btn-outline">+ Add Product</button>
            </a>
            <br><br><br>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Image</th>
                            <th scope="col">Title</th>
                            <th scope="col">Tags</th>
                            <th scope="col">Category</th>
                            <th scope="col">Credit</th>
                            <th scope="col">Information</th>
                            <th scope="col">Price</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <?php $__empty_1 = true; $__currentLoopData = $record; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <?php echo e($loop->iteration); ?>

                                </td>

                                <td>
                                    <?php if($value->category == "Video"): ?>
                                        <video width=200 height=200 controls>
                                            <source src="storage/product/<?php echo e($value->filename); ?>" type="video/mp4">
                                            <source src="storage/product/<?php echo e($value->filename); ?>" type="video/ogg">
                                            Your browser does not support the video tag.
                                        </video>
                                    <?php else: ?>
                                        <img src="storage/product/<?php echo e($value->filename); ?>" alt="<?php echo e($value->title); ?> Image" width=200 height=200>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <div class="mb5"><?php echo e($value->title); ?></div>
                                </td>

                                <td>
                                    <div class="mb5"><?php echo e($value->tags); ?></div>
                                </td>

                                <td>
                                    <div class="mb5"><?php echo e($value->category); ?></div>
                                </td>

                                <td>
                                    <div class="mb5"><?php echo e($value->credit); ?></div>                        
                                </td>

                                <td>
                                    <div class="mb5"><?php echo e($value->description); ?></div>    
                                </td>

                                <td>
                                    <div class="mb5"><?php echo e($value->price); ?></div>
                                </td>

                                <td>
                                    <button type="button" class="btn btn-sm btn-outline btn-raised dropdown-toggle" data-bs-toggle="dropdown">Actions <span class="caret"></span></button>
                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuSplitButton2">
                                        <a class="dropdown-item" href="<?php echo e(route('product.edit', [$value->id])); ?>">Edit</a>
                                        <form action="<?php echo e(route('product.delete', [$value->id])); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button class="dropdown-item" type="submit" onclick="return confirm('Delete the product?')">Delete</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9">
                                    <p class="text-center">No record found yet.</p>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tr>
                    </tbody>
                </table>
            </div>
            <br><br>
            <ul class="pagination" style="float:right !important; margin-right: 80px;">
                <li class="page-item" ><?php echo e($record->links()); ?></li>
            </ul>
        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\filospace\resources\views\product\index.blade.php ENDPATH**/ ?>