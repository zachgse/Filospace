

<?php $__env->startSection('content'); ?>

<style>
    table {
        background-color: white;
        width: 90% !important;
        margin: auto;
        text-align: center; 
    }

    thead {
        background-color: #e1e1e1;
        border: solid 1px #e1e1e1 !important;
    }

    th {
        border: none !important;
    }

    tr {
        vertical-align: middle;
    }

    td {
        max-width:100px; 
        word-wrap:break-word;
    }

    .btn-outline, .btn-outline:hover {
        background-color: #717C73 !important;
        color: white;
    }

</style>

<div class="container-fluid table-responsive">
    <div class="card" style="min-height: 90vh;">
        <div class="card-body p-5">
            <h4 class="text-center">List of Inquiries</h4>
            <br><hr><br>
            <?php echo $__env->make('layouts.notifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <br><br><br>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Description</th>
                            <th scope="col">Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <?php $__empty_1 = true; $__currentLoopData = $record; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <?php echo e($loop->iteration); ?>

                                </td>

                                <td>
                                    <div class="mb5"><?php echo e($value->name); ?></div>
                                </td>

                                <td>
                                    <div class="mb5"><?php echo e($value->email); ?></div>
                                </td>

                                <td>
                                    <div class="mb5"><?php echo e($value->description); ?></div>
                                </td>

                                <td>
                                    <div class="mb5"><?php echo e($value->created_at->format("d F Y h:i A")); ?></div>
                                </td>

                            
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5">
                                    <p class="text-center">No record found yet.</p>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tr>
                    </tbody>
                </table>
            </div>
            <br><br>
            <ul class="pagination" style="float:right !important; margin-right: 80px;">
                <li class="page-item" ><?php echo e($record->links()); ?></li>
            </ul>
        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\filospace\resources\views/admin/inquiry-index.blade.php ENDPATH**/ ?>