<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($page_title); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>
        .btn-size {
            width: 295px;
            height: 79px;
        }

        .btn-outline-2, .btn-outline-2:hover {
            background-color: white;
            color: black;
        }

        .row {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .img-fluid {
            width: 100%;
            height: 618px;
        }

        thead {
            background-color: #e1e1e1;
            border: solid 1px #e1e1e1 !important;
        }

        th {
            border: none !important;
        }

        tr {
            vertical-align: middle;
        }

        td {
            max-width:100px; 
            word-wrap:break-word;
        }

        .border {
            border: solid 2px white !important;
        }
        
    </style>

</head>
<body style="background-color:#717C73;">

<section>

    <nav class="navbar navbar-expand-xxl bg-light py-3 p-3" id="mobile-nav">
        <br>
        <div class="container-fluid">

            <a class="navbar-brand" href="<?php echo e(route('welcome')); ?>">
                <i class="bi bi-bootstrap-fill h2 align-middle"></i>
                <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Filospace logo">
            </a>

            <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerflex-1" aria-controls="navbarTogglerflex-1" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon">
                    <i class="fa fa-bars" style="color: white; font-size: 28px;"></i>
                </span>
            </button>

            <div class="collapse navbar-collapse align-items-center" id="navbarTogglerflex-1">
                <ul class="navbar-nav">        
                    <br><br>                    
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('welcome')); ?>">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('welcome')); ?>">Contact Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Boards</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Cart</a>
                    </li>
                    <li class="nav-item">
                        <?php if(auth()->guard()->guest()): ?>
                        <a href="<?php echo e(route('login')); ?>" class="nav-link">
                           LOGIN
                        </a>
                        <?php endif; ?>
                        <?php if(auth()->guard()->check()): ?>
                        <div class="dropdown nav-item text-white" style="cursor: pointer;">
                            <p class="dropdown-toggle text-center nav-link" data-bs-toggle="dropdown" aria-expanded="false">
                                <?php echo e(auth()->user()->name); ?>

                            </p>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="<?php echo e(route('admin.index')); ?>">Dashboard</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Logout</a></li>
                            </ul>
                        </div>
                        <?php endif; ?>
                    </li>
                </ul>
            </div>

        </div>
    </nav>

    <div class="d-flex justify-content-between text-white container-fluid" id="web-nav" style="background-color: #717C73; height: 100px;">
        <div class="d-flex flex-inline mt-5">
            <div class="m-1">
                <a href="<?php echo e(route('welcome')); ?>" class="links">
                    <img src="<?php echo e(asset('images/icon-about.png')); ?>" alt="About Us Icon"> ABOUT US
                </a>
            </div>

            <div class="m-1">
                <a href="<?php echo e(route('welcome')); ?>" class="links">
                    <img src="<?php echo e(asset('images/icon-contact.png')); ?>" alt="Contact Icon"> CONTACT US
                </a>
            </div>		
        </div>

        <div class="mt-5">
            <a href="<?php echo e(route('welcome')); ?>">
                <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Filospace logo">
            </a>
        </div>

        <div class="d-flex flex-inline mt-5">
            <div class="m-1">
                <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>" class="links" style="margin-right: 30px;">
                    <img src="<?php echo e(asset('images/icon-user.png')); ?>" class="mx-2" alt="Login Icon">LOGIN
                </a>
                <?php endif; ?>
                <?php if(auth()->guard()->check()): ?>
                <div class="dropdown links text-white" style="margin-right: 30px; cursor: pointer;">
                    <p class="dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="<?php echo e(asset('images/icon-user.png')); ?>" class="mx-1" alt="User Icon"> <?php echo e(auth()->user()->name); ?>

                    </p>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="<?php echo e(route('admin.index')); ?>">Dashboard</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Logout</a></li>
                    </ul>
                </div>
                <?php endif; ?>
            </div>
            <div class="m-1">
                <img src="<?php echo e(asset('images/icon-board.png')); ?>" alt="Board Icon"> BOARDS
            </div>
            <div class="m-1" data-bs-toggle="offcanvas" data-bs-target="#offcanvasDarkNavbar" aria-controls="offcanvasDarkNavbar" style="cursor:pointer;">
                <img src="<?php echo e(asset('images/icon-cart.png')); ?>" alt="Cart Icon"> CART
            </div>
        </div>
    </div>

    <br><br>

    <div class="input-group search-bar-2 mb-5 auto">
        <span class="input-group-text" id="basic-addon3">
            <div class="btn-group">
                <p class="btn btn-black dropdown-toggle text-white mt-3" data-bs-toggle="dropdown" aria-expanded="false">
                    Creative Images
                </p>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#">Action</a></li>
                    <li><a class="dropdown-item" href="#">Another action</a></li>
                    <li><a class="dropdown-item" href="#">Something else here</a></li>
                    <li><a class="dropdown-item" href="#">Another action</a></li>
                </ul>
            </div>
        </span>
        <i class="fa fa-search text-white" style="margin-top: 40px;"></i>
        <input type="text" class="form-control search-bar-input-2 text-white" placeholder="Start searching now">
    </div>

    <br><br><br>

    <div class="container-fluid">
        <div class="card text-white w-100" style="background-color: #1D1F1D; min-height: 75vh;">
            <div class="card-body p-5">
                <h4><?php echo e($product->title); ?></h4>
                <p>Media Tags: <?php echo e($product->tags); ?></p>
                <div class="row">
                    <div class="col-lg-7">
                        <?php if($product->category == "Video"): ?> 
                        <video width=100% height=100% controls>
                            <source src="<?php echo e(asset("storage/product/{$product->filename}")); ?>" type="video/mp4" class="border">
                            <source src="<?php echo e(asset("storage/product/{$product->filename}")); ?>" type="video/ogg" class="border">
                            Your browser does not support the video tag.
                        </video>
                        <?php else: ?> 
                            <img class="img-fluid border" src="<?php echo e(asset("storage/product/{$product->filename}")); ?>" alt="<?php echo e($product->title); ?> Image">
                        <?php endif; ?>
                    </div>
                    <div class="col-lg-5 text-center">
                        <p>
                            PURCHASE A LICENSE
                            <br><br> 
                            All Royalty-Free licenses include global use rights, comprehensive protection, 
                            <br>simple pricing with volume discounts available
                            <br><br>
                            ₱ <?php echo e($product->price); ?> PHP
                            <br><br>
                            <form action="<?php echo e(route('homepage.add-cart', [$product->id])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-size btn-success" onclick="return confirm('Add the product to the cart?')">
                                    ADD TO CART
                                </button>
                            </form>

                            <br>  
                            <a href="<?php echo e(asset('storage/product/' .$product->filename)); ?>" download>
                                <button class="btn btn-size btn-outline-2" onclick="return confirm('Download the item?')">GET A PRINT</button>
                            </a>
                            <br><br>
                            DETAILS
                            <br><br>
                            <div class="mb-3" style="margin-left: -220px;">
                                Credit: <span><?php echo e($product->credit); ?></span>
                            </div>
                            <div class="mb-3" style="margin-left: -164px;">
                                Creative number: <span><?php echo e($product->id); ?></span>
                            </div>
                            <div class="mb-3" style="margin-left: -126px;">
                                Product info: <span><?php echo e($product->description); ?></span>
                            </div>
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <br><br>
    </div>

    <div class="offcanvas offcanvas-end text-bg-dark" tabindex="-1" id="offcanvasDarkNavbar" aria-labelledby="offcanvasDarkNavbarLabel">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="offcanvasDarkNavbarLabel">Cart</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col"></th>
                        <th scope="col">Title</th>
                        <th scope="col">Category</th>
                        <th scope="col">Price</th>
                    </tr>
                </thead>
                <tbody class="text-white">
                    <tr>
                        <?php $__empty_1 = true; $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                            </td>

                            <td>
                                <div class="mb5"><?php echo e($value->product->title); ?></div>
                            </td>

                            <td>
                                <div class="mb5"><?php echo e($value->product->category); ?></div>
                            </td>


                            <td>
                                <div class="mb5"><?php echo e($value->product->price); ?></div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6">
                                <p class="text-center">No items in cart yet.</p>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

</section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\laragon\www\filospace\resources\views\homepage\show.blade.php ENDPATH**/ ?>