<?php if(session()->has('notification-status')): ?>
    <div class="alert alert-<?php echo e(in_array(session()->get('notification-status'),['failed','error','danger']) ? 'danger' : session()->get('notification-status')); ?>" role="alert">
        <?php echo e(session()->get('notification-msg')); ?>

    </div>
<?php endif; ?><?php /**PATH C:\laragon\www\filospace\resources\views\layouts\notifications.blade.php ENDPATH**/ ?>