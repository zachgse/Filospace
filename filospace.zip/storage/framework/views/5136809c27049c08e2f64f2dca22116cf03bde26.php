

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <h4 class="text-white">Welcome to the Dashboard, <?php echo e(auth()->user()->name); ?></h4>
        <br><br><br>

        <div class="d-flex text-center justify-content-center mb-3">
            <div class="p-2">
                <div class="card p-3" style="width: 18rem;">
                    <div class="card-body">
                        <h2 class="card-title"><?php echo e($product); ?></h2>
                        <br>
                        <p>Total number of Products</p>
                    </div>
                </div>
            </div>
            <div class="p-2">
                <div class="card p-3" style="width: 18rem;">
                    <div class="card-body">
                        <h2 class="card-title"><?php echo e($inquiry); ?></h2>
                        <br>
                        <p>Total number of Inquiries</p>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\filospace\resources\views\admin\index.blade.php ENDPATH**/ ?>