

<?php $__env->startSection('content'); ?>
<style>
input, textarea, select {
    background-color: #E1DFD9 !important;
    opacity: 0.6;
    color: black !important;
}

</style>

<div class="d-flex justify-content-center align-items-center">

    <div class="card mt-3" style="width: 1000px;">
        <div class="card-body p-4">
            <b>Media Edit Form</b>
            <br><br>
            <form method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="file">Upload Media</label>
                    <input type="file" class="form-control" name="filename">
                </div>
                <div class="mb-3">
                    <label for="name">Media Category</label>
                    <select name="category" class="form-control" value="<?php echo e($product->category); ?>">
                        <option value="<?php echo e($product->category); ?>"selected><?php echo e($product->category); ?></option>
                        <option value="Image">Image</option>
                        <option value="Video">Video</option>
                        <option value="Music">Music</option>
                        <option value="Vector">Vector</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="name">Media Title</label>
                    <input type="text" class="form-control" name="title" value="<?php echo e($product->title); ?>">
                </div>
                <div class="mb-3">
                    <label for="name">Media Tags</label>
                    <input type="text" class="form-control" name="tags" value="<?php echo e($product->tags); ?>">
                </div>
                <div class="mb-3">
                    <label for="name">Media Credit</label>
                    <input type="text" class="form-control" name="credit" value="<?php echo e($product->credit); ?>">
                </div>
                <div class="mb-3">
                    <label for="name">Product Information</label>
                    <textarea name="description" id="" cols="30" rows="10" class="form-control" value="<?php echo e($product->description); ?>"><?php echo e($product->description); ?></textarea>
                </div>

                <div class="mb-3">
                    <label for="price">Price</label>
                    <input type="number" class="form-control" name="price" value="<?php echo e($product->price); ?>">
                </div>

                <button class="btn btn-outline text-white" type="submit" onclick="return confirm('Update the product?')" style="float:right; background-color: #717C73;">Update</button>
            </form>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\filospace\resources\views\product\edit.blade.php ENDPATH**/ ?>