<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($page_title); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>
        .btn-size {
            width: 295px;
            height: 79px;
        }

        .btn-outline-2, .btn-outline-2:hover {
            background-color: white;
            color: black;
        }

        .row {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .img-fluid {
            width: 100%;
            height: 618px;
        }

        thead {
            background-color: #e1e1e1;
            border: solid 1px #e1e1e1 !important;
        }

        th {
            border: none !important;
        }

        tr {
            vertical-align: middle;
        }

        td {
            max-width:100px; 
            word-wrap:break-word;
        }

        .border {
            border: solid 2px white !important;
        }
        
    </style>

</head>
<body style="background-color:#717C73;">

<section>

    <nav class="navbar navbar-expand-xxl bg-light py-3 p-3" id="mobile-nav">
        <br>
        <div class="container-fluid">

            <a class="navbar-brand" href="<?php echo e(route('welcome')); ?>">
                <i class="bi bi-bootstrap-fill h2 align-middle"></i>
                <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Filospace logo">
            </a>

            <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerflex-1" aria-controls="navbarTogglerflex-1" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon">
                    <i class="fa fa-bars" style="color: white; font-size: 28px;"></i>
                </span>
            </button>

            <div class="collapse navbar-collapse align-items-center" id="navbarTogglerflex-1">
                <ul class="navbar-nav">        
                    <br><br>                    
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('welcome')); ?>">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('welcome')); ?>">Contact Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Boards</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Cart</a>
                    </li>
                    <li class="nav-item">
                        <?php if(auth()->guard()->guest()): ?>
                        <a href="<?php echo e(route('login')); ?>" class="nav-link">
                           LOGIN
                        </a>
                        <?php endif; ?>
                        <?php if(auth()->guard()->check()): ?>
                        <div class="dropdown nav-item text-white" style="cursor: pointer;">
                            <p class="dropdown-toggle text-center nav-link" data-bs-toggle="dropdown" aria-expanded="false">
                                <?php echo e(auth()->user()->name); ?>

                            </p>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="<?php echo e(route('admin.index')); ?>">Dashboard</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Logout</a></li>
                            </ul>
                        </div>
                        <?php endif; ?>
                    </li>
                </ul>
            </div>

        </div>
    </nav>

    <div class="d-flex justify-content-between text-white container-fluid" id="web-nav" style="background-color: #717C73; height: 100px;">
        <div class="d-flex flex-inline mt-5">
            <div class="m-1">
                <a href="<?php echo e(route('welcome')); ?>" class="links">
                    <img src="<?php echo e(asset('images/icon-about.png')); ?>" alt="About Us Icon"> ABOUT US
                </a>
            </div>

            <div class="m-1">
                <a href="<?php echo e(route('welcome')); ?>" class="links">
                    <img src="<?php echo e(asset('images/icon-contact.png')); ?>" alt="Contact Icon"> CONTACT US
                </a>
            </div>		
        </div>

        <div class="mt-5">
            <a href="<?php echo e(route('welcome')); ?>">
                <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Filospace logo">
            </a>
        </div>

        <div class="d-flex flex-inline mt-5">
            <div class="m-1">
                <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>" class="links" style="margin-right: 30px;">
                    <img src="<?php echo e(asset('images/icon-user.png')); ?>" class="mx-2" alt="Login Icon">LOGIN
                </a>
                <?php endif; ?>
                <?php if(auth()->guard()->check()): ?>
                <div class="dropdown links text-white" style="margin-right: 30px; cursor: pointer;">
                    <p class="dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="<?php echo e(asset('images/icon-user.png')); ?>" class="mx-1" alt="User Icon"> <?php echo e(auth()->user()->name); ?>

                    </p>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="<?php echo e(route('admin.index')); ?>">Dashboard</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Logout</a></li>
                    </ul>
                </div>
                <?php endif; ?>
            </div>
            <div class="m-1">
                <img src="<?php echo e(asset('images/icon-board.png')); ?>" alt="Board Icon"> BOARDS
            </div>
            <div class="m-1" data-bs-toggle="offcanvas" data-bs-target="#offcanvasDarkNavbar" aria-controls="offcanvasDarkNavbar" style="cursor:pointer;">
                <img src="<?php echo e(asset('images/icon-cart.png')); ?>" alt="Cart Icon"> CART
            </div>
        </div>
    </div>

    <br><br>

    <form class="input-group search-bar-2 mb-5 auto" method="POST" action="<?php echo e(route('homepage.search')); ?>">
        <?php echo csrf_field(); ?>
        <span class="input-group-text" id="basic-addon3">
            <div class="btn-group">
                <select name="tag" class="form-control btn-black">
                    <option value="" selected disabled hidden>Category</option>
                    <option value="Creative">Images</option>
                    <option value="Video">Video</option>
                    <option value="Music">Music</option>
                    <option value="Vector">Vector</option>
                </select>
            </div>
        </span>
        <button style="border: none; background-color: transparent;">
            <i class="fa fa-search text-white"></i>
        </button>
        <input type="text" class="form-control search-bar-input-2 text-white" placeholder="Start searching now" name="keyword">
    </form>

    <br><br><br>

    <div class="container-fluid">
        <div class="card text-white w-100" style="background-color: #1D1F1D; min-height: 75vh;">
            <div class="card-body p-5">
                <h4>Result for Video</h4>
                <br><hr><br>
                <div class="card-group">
                    <div class="card img-wrapper">
                        <img src="images/sample-img.png" alt="" width="auto" class="img-fluid inner-img">
                    </div>
                    <div class="card img-wrapper">
                        <img src="images/sample-img.png" alt="" width="auto" class="img-fluid inner-img">
                    </div>
                    <div class="card img-wrapper">
                        <img src="images/sample-img.png" alt="" width="auto" class="img-fluid inner-img">
                    </div>
                    <div class="card img-wrapper">
                        <img src="images/sample-img.png" alt="" width="auto" class="img-fluid inner-img">
                    </div>
                </div>
            
            </div>
        </div>
        <br><br>
    </div>



</section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\laragon\www\filospace\resources\views\homepage\video.blade.php ENDPATH**/ ?>