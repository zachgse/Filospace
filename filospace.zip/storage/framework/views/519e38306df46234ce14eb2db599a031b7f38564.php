<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Filospace</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Carousel CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css"/>
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>

    <section class="bg-image">

        <nav class="navbar navbar-expand-xxl bg-light py-3 p-3" id="mobile-nav">
            <br>
            <div class="container-fluid">
    
                <a class="navbar-brand" href="#">
                    <i class="bi bi-bootstrap-fill h2 align-middle"></i>
                    <img src="images/logo.png" alt="Filospace logo">
                </a>
    
                <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerflex-1" aria-controls="navbarTogglerflex-1" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon">
                        <i class="fa fa-bars" style="color: white; font-size: 28px;"></i>
                    </span>
                </button>

                <div class="collapse navbar-collapse align-items-center" id="navbarTogglerflex-1">
                    <ul class="navbar-nav">        
                        <br><br>                    
                        <li class="nav-item">
                            <a class="nav-link" href="#section-3">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#section-4">Contact Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Boards</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Cart</a>
                        </li>
                        <li class="nav-item">
                        <?php if(auth()->guard()->guest()): ?>
                        <a href="<?php echo e(route('login')); ?>" class="nav-link">
                           LOGIN
                        </a>
                        <?php endif; ?>
                        <?php if(auth()->guard()->check()): ?>
                        <div class="dropdown nav-item text-white" style="cursor: pointer;">
                            <p class="dropdown-toggle text-center nav-link" data-bs-toggle="dropdown" aria-expanded="false">
                                <?php echo e(auth()->user()->name); ?>

                            </p>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="<?php echo e(route('admin.index')); ?>">Dashboard</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Logout</a></li>
                            </ul>
                        </div>
                        <?php endif; ?>
                        </li>
                    </ul>
                </div>
    
            </div>
        </nav>

        <br><br>

        <div class="d-flex justify-content-between text-white container-fluid mb-5" id="web-nav">
            <div class="d-flex flex-inline">
                <div class="m-1">
                    <a href="#section-3" class="links">
                        <img src="images/icon-about.png" alt="About Us Icon"> ABOUT US
                    </a>
                </div>

                <div class="m-1">
                    <a href="#section-4" class="links">
                        <img src="images/icon-contact.png" alt="Contact Icon"> CONTACT US
                    </a>
                </div>		
            </div>

            <div>
                <a href="/">
                    <img src="images/logo.png" alt="Filospace logo">
                </a>
            </div>

            <div class="d-flex flex-inline">
                <div class="m-1">
                    <?php if(auth()->guard()->guest()): ?>
                    <a href="<?php echo e(route('login')); ?>" class="links" style="margin-right: 30px;">
                        <img src="<?php echo e(asset('images/icon-user.png')); ?>" class="mx-2" alt="Login Icon">LOGIN
                    </a>
                    <?php endif; ?>
                    <?php if(auth()->guard()->check()): ?>
                    <div class="dropdown links text-white" style="margin-right: 30px; cursor: pointer;">
                        <p class="dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                            <img src="<?php echo e(asset('images/icon-user.png')); ?>" class="mx-1" alt="User Icon"> <?php echo e(auth()->user()->name); ?>

                        </p>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="<?php echo e(route('admin.index')); ?>">Dashboard</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Logout</a></li>
                        </ul>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="m-1">
                    <img src="images/icon-board.png" alt="Board Icon"> BOARDS
                </div>
                <div class="m-1">
                    <img src="images/icon-cart.png" alt="Cart Icon"> CART
                </div>
            </div>
        </div>

        <nav class="navbar navbar-expand-lg bg-body-tertiary d-flex justify-content-evenly mb-5">
            
            <div class="p-2 text-white">
                <a href="<?php echo e(route('homepage.creative')); ?>" class="links">IMAGE</a>   
            </div>
            <div class="p-2 text-white">
                <a href="<?php echo e(route('homepage.video')); ?>" class="links">VIDEO</a>   
            </div>
            <div class="p-2 text-white">
                <a href="<?php echo e(route('homepage.music')); ?>" class="links">MUSIC</a>   
            </div>
            <div class="p-2 text-white">
                <a href="<?php echo e(route('homepage.vector')); ?>" class="links">VECTOR</a>   
            </div>

        </nav>

        <div>
            <p class="text-white text-center" style="font-size:28px;">Authentic Filipino content for your creative needs</p>
        </div>

        <div>
            <form class="input-group search-bar mb-3 auto" method="POST" action="<?php echo e(route('homepage.search')); ?>">
                <?php echo csrf_field(); ?>
                <span class="input-group-text" id="basic-addon1">
                    <button style="border: none; background-color: transparent;">
                        <i class="fa fa-search"></i>
                    </button>
                </span>
                <input type="text" class="form-control search-bar-input" name="keyword" placeholder="Search the Philippines' best creative photos and images">
                <span class="input-group-text" id="basic-addon2">
                    <div class="btn-group">
                    <select name="tag" class="form-control btn-white">
                        <option value="" selected disabled hidden>Category</option>
                        <option value="Creative">Images</option>
                        <option value="Video">Video</option>
                        <option value="Music">Music</option>
                        <option value="Vector">Vector</option>
                    </select>
                    </div>
                </span>
            </form>
        </div>

        <p class="bottom-text">Scroll to explore</p>
    </section>

    <section id="section-2">
        <br><br><br>
        <form class="input-group search-bar-2 mb-5 auto" method="POST" action="<?php echo e(route('homepage.search')); ?>">
            <?php echo csrf_field(); ?>
            <span class="input-group-text" id="basic-addon3">
                <div class="btn-group">
                    <select name="tag" class="form-control btn-black">
                        <option value="" selected disabled hidden>Category</option>
                        <option value="Creative">Images</option>
                        <option value="Video">Video</option>
                        <option value="Music">Music</option>
                        <option value="Vector">Vector</option>
                    </select>
                </div>
            </span>
            <button style="border: none; background-color: transparent;">
                <i class="fa fa-search text-white"></i>
            </button>
            <input type="text" class="form-control search-bar-input-2 text-white" placeholder="Start searching now" name="keyword">
        </form>

        <br><br><br><br><br>

        <?php if($creatives->isEmpty()): ?>
        <div class="card-group">
            <div class="card img-wrapper">
                <img src="images/sample-img.png" alt="" width="auto" class="img-fluid inner-img">
            </div>
            <div class="card img-wrapper">
                <img src="images/sample-img.png" alt="" width="auto" class="img-fluid inner-img">
            </div>
            <div class="card img-wrapper">
                <img src="images/sample-img.png" alt="" width="auto" class="img-fluid inner-img">
            </div>
            <div class="card img-wrapper">
                <img src="images/sample-img.png" alt="" width="auto" class="img-fluid inner-img">
            </div>
        </div>
        <?php else: ?>
        <div class="card-group">
            <?php $__currentLoopData = $creatives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $creative): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card img-wrapper">
                <a href="<?php echo e(route('homepage.show', [$creative->id])); ?>"  target="_blank" style="width: 100%; height: 100%;">
                    <img src="storage/product/<?php echo e($creative->filename); ?>" class="inner-img" alt="<?php echo e($creative->title); ?> Image" style="width: 100%; height: 100%;">
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

        <?php if($videos->isEmpty()): ?>
        <div class="card-group">
            <div class="card img-wrapper">
                <img src="images/sample-img.png" alt="" width="auto" class="img-fluid inner-img">
            </div>
            <div class="card img-wrapper">
                <img src="images/sample-img.png" alt="" width="auto" class="img-fluid inner-img">
            </div>
            <div class="card img-wrapper">
                <img src="images/sample-img.png" alt="" width="auto" class="img-fluid inner-img">
            </div>
            <div class="card img-wrapper">
                <img src="images/sample-img.png" alt="" width="auto" class="img-fluid inner-img">
            </div>
        </div>
        <?php else: ?>
        <div class="card-group">
            <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <a href="<?php echo e(route('homepage.show', [$video->id])); ?>" target="_blank" style="width: 100%; height: 100%;">
                    <video width=100% height=100% controls>
                        <source src="storage/product/<?php echo e($video->filename); ?>" type="video/mp4">
                        <source src="storage/product/<?php echo e($video->filename); ?>" type="video/ogg">
                        Your browser does not support the video tag.
                    </video>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

        <?php if($vectors->isEmpty()): ?>
        <div class="card-group">
            <div class="card img-wrapper">
                <img src="images/sample-img.png" alt="" width="auto" class="img-fluid inner-img">
            </div>
            <div class="card img-wrapper">
                <img src="images/sample-img.png" alt="" width="auto" class="img-fluid inner-img">
            </div>
            <div class="card img-wrapper">
                <img src="images/sample-img.png" alt="" width="auto" class="img-fluid inner-img">
            </div>
            <div class="card img-wrapper">
                <img src="images/sample-img.png" alt="" width="auto" class="img-fluid inner-img">
            </div>
        </div>
        <?php else: ?>
        <div class="card-group">
            <?php $__currentLoopData = $vectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card img-wrapper">
                <a href="<?php echo e(route('homepage.show', [$vector->id])); ?>"  target="_blank" style="width: 100%; height: 100%;">
                    <img src="storage/product/<?php echo e($vector->filename); ?>" class="inner-img" alt="<?php echo e($vector->title); ?> Image" style="width: 100%; height: 100%;">
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

    </section>

    <section id="section-3">
        <br><br><br><br><br><br>
        <h3 class="text-white text-center letter-space my-5">ABOUT US</h3>

        <div class="wrapper-with-margin">
            <div id="owl-demo" class="owl-carousel">
                <div>
                    <img src="images/sample-img.png" class="img-fluid">
                    <p class="text-white mt-3"><b>Title 1</b></p>
                </div>

                <div>
                    <img src="images/sample-img.png" class="img-fluid">
                    <p class="text-white mt-3"><b>Title 2</b></p>
                </div>

                <div>
                    <img src="images/sample-img.png" class="img-fluid">
                    <p class="text-white mt-3"><b>Title 3</b></p>
                </div>

                <div>
                    <img src="images/sample-img.png" class="img-fluid">
                    <p class="text-white mt-3"><b>Title 4</b></p>
                </div>

                <div>
                    <img src="images/sample-img.png" class="img-fluid">
                    <p class="text-white mt-3"><b>Title 5</b></p>
                </div>

                <div>
                    <img src="images/sample-img.png" class="img-fluid">
                    <p class="text-white mt-3"><b>Title 6</b></p>
                </div>

                <div>
                    <img src="images/sample-img.png" class="img-fluid">
                    <p class="text-white mt-3"><b>Title 7</b></p>
                </div>

            </div>
        </div>

        <div class="container">
            <div class="card-group">
                <div class="card text-center">
                    <div class="card-body p-5">
                        <h4>Our Mission</h4>
                        <p class="card-text">
                            Our mission is to provide high-quality and diverse visual and audio content that empowers creatives, businesses, 
                            and individuals to bring their ideas to life. We strive to offer a rich collection of stock photos, videos, vectors, 
                            and sounds that reflect the beauty and uniqueness of the Philippines while catering to the global market's needs.
                        </p>
                    </div>
                </div>

                <div class="card text-center">
                    <div class="card-body p-5">
                        <h4>Our Values</h4>
                        <p class="card-text">
                            At FILOSPACE, we value creativity, diversity, quality, and affordability. We strive to foster a culture of continuous 
                            learning and improvement and are committed to providing exceptional customer service. We believe in supporting our 
                            local community of artists and creators and are dedicated to creating an inclusive and equitable work environment. 
                            Our values guide our actions and decisions as we continue to grow and evolve as a company.
                        </p>
                    </div>
                </div>

                <div class="card text-center">
                    <div class="card-body p-5">
                        <h4>Our Vision</h4>
                        <p class="card-text">
                            Our vision is to become the leading stock media platform in the Philippines, offering exceptional and affordable stock media 
                            content to a broad range of users. We aim to create a community of photographers, videographers, sound engineers, and artists 
                            who share our passion for capturing the essence of the Philippines and providing excellent service to our clients.
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <br><br><br><br>
    </section>

    <section class="bg-image-2 d-flex justify-content-center align-items-center" id="section-4">

        <div class="card contact-form auto p-5">
            <div class="card-body text-center">
                <h5 class="card-title text-white letter-space">CONTACT US</h5>
                <br><br><br>
                <?php echo $__env->make('layouts.notifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form action="<?php echo e(route('homepage.inquiry')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="text" class="form-control contact-us-input mb-5" placeholder="Name" name="name">
                    <input type="email" class="form-control contact-us-input mb-5" placeholder="Email" name="email">
                    <textarea rows="7" cols="50" placeholder="Write Something"  class="form-control contact-us-textarea mb-5" name="description"></textarea>
                    <button class="btn btn-success" style="color:white; width: 160px; height:64px;">Submit</button>
                </form>
            </div>
        </div>

    </section>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <!--Jquery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!-- Owl Carousel -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function () {
                var carousel = $("#owl-demo");
                carousel.owlCarousel({
                items: 4,
                loop:true,
                nav: true,
                autoplay: true,
                navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
                responsiveClass:true,
                responsive:{
                    0:{
                        items:1
                    },
                    600:{
                        items:2
                    },
                    1000:{
                        items:4
                    }
                }
            });  
        });
    </script>
</body>
</html><?php /**PATH C:\laragon\www\filospace\resources\views\welcome.blade.php ENDPATH**/ ?>